import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserRegisterService {

  constructor(private http:HttpClient) { }

  public doRegistration(citizen){
    return this.http.post("liiink",citizen,{responseType: 'text' as 'json' })
  }
}
