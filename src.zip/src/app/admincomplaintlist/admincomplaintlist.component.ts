import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admincomplaintlist',
  templateUrl: './admincomplaintlist.component.html',
  styleUrls: ['./admincomplaintlist.component.css']
})
export class AdmincomplaintlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
