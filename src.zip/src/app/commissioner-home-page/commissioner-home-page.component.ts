import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commissioner-home-page',
  templateUrl: './commissioner-home-page.component.html',
  styleUrls: ['./commissioner-home-page.component.css']
})
export class CommissionerHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
