import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-present-complaints',
  templateUrl: './present-complaints.component.html',
  styleUrls: ['./present-complaints.component.css']
})
export class PresentComplaintsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
