import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { profile } from 'console';
import { AdminHomePageComponent } from './admin-home-page/admin-home-page.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdmincomplaintlistComponent } from './admincomplaintlist/admincomplaintlist.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { CheckStatusComponent } from './check-status/check-status.component';
import { CitizenHomePageComponent } from './citizen-home-page/citizen-home-page.component';
import { CommisionerRegisterComponent } from './commisioner-register/commisioner-register.component';
import { CommissionerHomePageComponent } from './commissioner-home-page/commissioner-home-page.component';
import { CommissionerProfileComponent } from './commissioner-profile/commissioner-profile.component';
import { ComplaintRegisterComponent } from './complaint-register/complaint-register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PastComplaintsComponent } from './past-complaints/past-complaints.component';
import { PresentComplaintsComponent } from './present-complaints/present-complaints.component';
import { RegisterComponent } from './register/register.component';
import { SiteEngineerRegisterComponent } from './site-engineer-register/site-engineer-register.component';
import { WardComplaintListComponent } from './ward-complaint-list/ward-complaint-list.component';
import { WardHomePageComponent } from './ward-home-page/ward-home-page.component';
import { WardOfficerRegisterComponent } from './ward-officer-register/ward-officer-register.component';
import { WardProfileComponent } from './ward-profile/ward-profile.component';
import { ProfileComponent } from  './profile/profile.component'


const routes: Routes = [
   
  {path:'home', component: HomeComponent},
  {path:'login', component: LoginComponent},
  {path:'register', component: RegisterComponent},
  {path:'citizenHome', component: CitizenHomePageComponent},
  {path:'complaintRegister', component: ComplaintRegisterComponent},
  {path:'status', component: CheckStatusComponent},
  {path:'AdminLogin', component:AdminLoginComponent},
  {path:'adminHome', component:AdminHomePageComponent},
  {path:'commisioner', component:CommisionerRegisterComponent},
  {path:'wardOfficer', component:WardOfficerRegisterComponent},
  {path:'siteEngineer', component:SiteEngineerRegisterComponent},
  {path: 'adcomplaintlist', component:AdmincomplaintlistComponent},
  {path:'adminprofile', component:AdminprofileComponent},
  {path:'wardHome', component:WardHomePageComponent},
  {path:'wardComplaintList', component:WardComplaintListComponent},
  {path:'wardProfile', component:WardProfileComponent},
  {path:'commHome', component:CommissionerHomePageComponent},
  {path:'preComplaint', component:PresentComplaintsComponent},
  {path:'pastComplaint', component:PastComplaintsComponent},
  {path:'wardList', component:WardOfficerRegisterComponent},
  {path:'commProfile', component:CommissionerProfileComponent},
 // {path:'citizenProfile', component:citiz}
  {path:'citizenProfile', component:ProfileComponent},
  {path:'', redirectTo: '/home', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
