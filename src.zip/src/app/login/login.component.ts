import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email:string;
  password:string;
  result:any;
  constructor(private http:HttpClient) { }

 /* postData(){
    let url="http://httpbin.org/post";
    this.http.post(url,{em}).toPromise().then((data:any)=>{
        console.log(data);
        //console.log(stringify(data));
        //this.result=JSON.stringify(data);
      })
    //console.log(this.firstName);
  }*/

  
  
  ngOnInit(): void {
  }

}
