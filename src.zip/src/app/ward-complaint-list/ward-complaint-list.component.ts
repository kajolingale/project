import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-complaint-list',
  templateUrl: './ward-complaint-list.component.html',
  styleUrls: ['./ward-complaint-list.component.css']
})
export class WardComplaintListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
