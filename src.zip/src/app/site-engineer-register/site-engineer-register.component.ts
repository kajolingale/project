import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-engineer-register',
  templateUrl: './site-engineer-register.component.html',
  styleUrls: ['./site-engineer-register.component.css']
})
export class SiteEngineerRegisterComponent implements OnInit {

  Name:string
  comemail:string
  compassword:string
  comphoneNumber:string
  comaddress:string
  comarea:string

  getData(){
    
    console.log(this.comarea);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
