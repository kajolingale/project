import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteEngineerRegisterComponent } from './site-engineer-register.component';

describe('SiteEngineerRegisterComponent', () => {
  let component: SiteEngineerRegisterComponent;
  let fixture: ComponentFixture<SiteEngineerRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiteEngineerRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteEngineerRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
