import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-officer-register',
  templateUrl: './ward-officer-register.component.html',
  styleUrls: ['./ward-officer-register.component.css']
})
export class WardOfficerRegisterComponent implements OnInit {

  woName:string
  woemail:string
  wopassword:string
  wophoneNumber:string
  woaddress:string
  woarea:string

  getData(){
    
    console.log(this.woarea);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
