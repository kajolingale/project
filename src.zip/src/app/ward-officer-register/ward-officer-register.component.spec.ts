import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardOfficerRegisterComponent } from './ward-officer-register.component';

describe('WardOfficerRegisterComponent', () => {
  let component: WardOfficerRegisterComponent;
  let fixture: ComponentFixture<WardOfficerRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardOfficerRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardOfficerRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
