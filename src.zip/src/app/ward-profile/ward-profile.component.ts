import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-profile',
  templateUrl: './ward-profile.component.html',
  styleUrls: ['./ward-profile.component.css']
})
export class WardProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
