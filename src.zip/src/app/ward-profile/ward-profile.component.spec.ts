import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardProfileComponent } from './ward-profile.component';

describe('WardProfileComponent', () => {
  let component: WardProfileComponent;
  let fixture: ComponentFixture<WardProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
