import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommissionerProfileComponent } from './commissioner-profile.component';

describe('CommissionerProfileComponent', () => {
  let component: CommissionerProfileComponent;
  let fixture: ComponentFixture<CommissionerProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommissionerProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommissionerProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
