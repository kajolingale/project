import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  list:any;
  firstName:string;
        lastName:string;
        email:string;
        phoneNumber:string;
        address:string;
        gender:string;
        role:string;
        bdate:string;


  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }

  disque(){
    const url1="";
    const result=this.http.get(url1).toPromise();
    this.list=JSON.stringify(result);
    console.log(result)
    
  }
}
