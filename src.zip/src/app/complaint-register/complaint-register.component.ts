import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaint-register',
  templateUrl: './complaint-register.component.html',
  styleUrls: ['./complaint-register.component.css']
})
export class ComplaintRegisterComponent implements OnInit {
  Description: string
  ComplaintArea:string
  image1:Blob
  image2:string
  image3:string
  

  getData(){
    
    console.log(this.Description);
    console.log(this.image1);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
