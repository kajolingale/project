import { Component, OnInit } from '@angular/core';
//import { FormControl, FormBuilder} from '@angular/forms';
//import { url } from 'inspector';
import { Citizen } from '../citizen';
import { UserRegisterService } from '../user-register.service';
import { HttpClient } from '@angular/common/http';
import { stringify } from '@angular/compiler/src/util';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  

 // message:any;
        firstName:string;
        lastName:string;
        email:string;
        phoneNumber:string;
        address:string;
        gender:string;
        role:string;
        bdate:string;

        result:any;

        

  postData(){
    let url="http://httpbin.org/post";
    this.http.post(url,{role:this.role, firstName:this.firstName, lastName:this.lastName, email:this.email, phoneNumber:this.phoneNumber, 
      address:this.address, birthdate:this.bdate, gender:this.gender}).toPromise().then((data:any)=>{
        console.log(data);
        console.log(stringify(data));
        this.result=JSON.stringify(data);
      })
    //console.log(this.firstName);
  }

  data(){
  
    console.log();
       // console.log(stringify());
  }

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }

  /*public registerNow(){
    let resp=this.service.doRegistration(this.citizen);
    resp.subscribe((data)=>this.message=data);
  }*/
}
