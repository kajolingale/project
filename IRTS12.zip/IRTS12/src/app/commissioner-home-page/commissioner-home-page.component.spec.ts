import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommissionerHomePageComponent } from './commissioner-home-page.component';

describe('CommissionerHomePageComponent', () => {
  let component: CommissionerHomePageComponent;
  let fixture: ComponentFixture<CommissionerHomePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommissionerHomePageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommissionerHomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
