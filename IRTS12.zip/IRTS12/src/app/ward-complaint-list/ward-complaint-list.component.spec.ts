import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardComplaintListComponent } from './ward-complaint-list.component';

describe('WardComplaintListComponent', () => {
  let component: WardComplaintListComponent;
  let fixture: ComponentFixture<WardComplaintListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardComplaintListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardComplaintListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
