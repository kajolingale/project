import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardHomePageComponent } from './ward-home-page.component';

describe('WardHomePageComponent', () => {
  let component: WardHomePageComponent;
  let fixture: ComponentFixture<WardHomePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardHomePageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardHomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
