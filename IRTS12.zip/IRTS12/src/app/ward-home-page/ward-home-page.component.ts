import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-home-page',
  templateUrl: './ward-home-page.component.html',
  styleUrls: ['./ward-home-page.component.css']
})
export class WardHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
