import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { stringify } from '@angular/compiler/src/util';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  list:any;
  firstName:string;
        lastName:string;
        email:string;
        phoneNumber:string;
        address:string;
        gender:string;
        role:string;
        bdate:string;
        result:any;


  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }

  disque(){
    const url1="";
    const result=this.http.get(url1).toPromise();
    this.list=JSON.stringify(result);
    console.log(result)
    
  }

  postData(){
    let url="http://httpbin.org/post";
    this.http.post(url,{role:this.role, firstName:this.firstName, lastName:this.lastName, email:this.email, phoneNumber:this.phoneNumber, 
      address:this.address, birthdate:this.bdate, gender:this.gender}).toPromise().then((data:any)=>{
        console.log(data);
        console.log(stringify(data));
        this.result=JSON.stringify(data);
      })
    //console.log(this.firstName);
  }


}
