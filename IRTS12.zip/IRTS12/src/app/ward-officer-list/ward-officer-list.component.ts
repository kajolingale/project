import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-officer-list',
  templateUrl: './ward-officer-list.component.html',
  styleUrls: ['./ward-officer-list.component.css']
})
export class WardOfficerListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
