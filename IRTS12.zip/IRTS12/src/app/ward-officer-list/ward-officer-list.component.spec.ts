import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardOfficerListComponent } from './ward-officer-list.component';

describe('WardOfficerListComponent', () => {
  let component: WardOfficerListComponent;
  let fixture: ComponentFixture<WardOfficerListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardOfficerListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardOfficerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
