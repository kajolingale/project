import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-past-complaints',
  templateUrl: './past-complaints.component.html',
  styleUrls: ['./past-complaints.component.css']
})
export class PastComplaintsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
