import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PastComplaintsComponent } from './past-complaints.component';

describe('PastComplaintsComponent', () => {
  let component: PastComplaintsComponent;
  let fixture: ComponentFixture<PastComplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PastComplaintsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PastComplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
