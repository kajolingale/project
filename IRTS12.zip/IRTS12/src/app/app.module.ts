import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { FormsModule } from '@angular/forms';
import { CitizenHomePageComponent } from './citizen-home-page/citizen-home-page.component';
import { ComplaintRegisterComponent } from './complaint-register/complaint-register.component';
import { CheckStatusComponent } from './check-status/check-status.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomePageComponent } from './admin-home-page/admin-home-page.component';
import { CommisionerRegisterComponent } from './commisioner-register/commisioner-register.component';
import { WardOfficerRegisterComponent } from './ward-officer-register/ward-officer-register.component';
import { SiteEngineerRegisterComponent } from './site-engineer-register/site-engineer-register.component';
import { AdmincomplaintlistComponent } from './admincomplaintlist/admincomplaintlist.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { WardHomePageComponent } from './ward-home-page/ward-home-page.component';
import { WardComplaintListComponent } from './ward-complaint-list/ward-complaint-list.component';
import { WardProfileComponent } from './ward-profile/ward-profile.component'
import { UserRegisterService } from './user-register.service';
import {HttpClientModule} from '@angular/common/http';
import { CommissionerHomePageComponent } from './commissioner-home-page/commissioner-home-page.component';
import { PresentComplaintsComponent } from './present-complaints/present-complaints.component';
import { PastComplaintsComponent } from './past-complaints/past-complaints.component';
import { WardOfficerListComponent } from './ward-officer-list/ward-officer-list.component';
import { CommissionerProfileComponent } from './commissioner-profile/commissioner-profile.component';
import { ProfileComponent } from './profile/profile.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    CitizenHomePageComponent,
    ComplaintRegisterComponent,
    CheckStatusComponent,
    AdminLoginComponent,
    AdminHomePageComponent,
    CommisionerRegisterComponent,
    WardOfficerRegisterComponent,
    SiteEngineerRegisterComponent,
    AdmincomplaintlistComponent,
    AdminprofileComponent,
    WardHomePageComponent,
    WardComplaintListComponent,
    WardProfileComponent,
    CommissionerHomePageComponent,
    PresentComplaintsComponent,
    PastComplaintsComponent,
    WardOfficerListComponent,
    CommissionerProfileComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [UserRegisterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
