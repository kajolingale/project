import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PresentComplaintsComponent } from './present-complaints.component';

describe('PresentComplaintsComponent', () => {
  let component: PresentComplaintsComponent;
  let fixture: ComponentFixture<PresentComplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PresentComplaintsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PresentComplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
