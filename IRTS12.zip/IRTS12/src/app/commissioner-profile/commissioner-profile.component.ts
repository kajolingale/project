import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commissioner-profile',
  templateUrl: './commissioner-profile.component.html',
  styleUrls: ['./commissioner-profile.component.css']
})
export class CommissionerProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
