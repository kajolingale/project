import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommisionerRegisterComponent } from './commisioner-register.component';

describe('CommisionerRegisterComponent', () => {
  let component: CommisionerRegisterComponent;
  let fixture: ComponentFixture<CommisionerRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommisionerRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommisionerRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
