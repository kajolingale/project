import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commisioner-register',
  templateUrl: './commisioner-register.component.html',
  styleUrls: ['./commisioner-register.component.css']
})
export class CommisionerRegisterComponent implements OnInit {
  Name:string
  comemail:string
  compassword:string
  comphoneNumber:string
  comaddress:string
  comarea:string

  getData(){
    
    console.log(this.comarea);
  }

  constructor() { }

  ngOnInit(): void {
  }
}
