import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmincomplaintlistComponent } from './admincomplaintlist.component';

describe('AdmincomplaintlistComponent', () => {
  let component: AdmincomplaintlistComponent;
  let fixture: ComponentFixture<AdmincomplaintlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdmincomplaintlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmincomplaintlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
