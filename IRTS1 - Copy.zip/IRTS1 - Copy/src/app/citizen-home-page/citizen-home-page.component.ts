import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-home-page',
  templateUrl: './citizen-home-page.component.html',
  styleUrls: ['./citizen-home-page.component.css']
})
export class CitizenHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
