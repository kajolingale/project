import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminHomePageComponent } from './admin-home-page/admin-home-page.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdmincomplaintlistComponent } from './admincomplaintlist/admincomplaintlist.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { CheckStatusComponent } from './check-status/check-status.component';
import { CitizenHomePageComponent } from './citizen-home-page/citizen-home-page.component';
import { CommisionerRegisterComponent } from './commisioner-register/commisioner-register.component';
import { ComplaintRegisterComponent } from './complaint-register/complaint-register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SiteEngineerRegisterComponent } from './site-engineer-register/site-engineer-register.component';
import { WardOfficerRegisterComponent } from './ward-officer-register/ward-officer-register.component';


const routes: Routes = [
   
  {path:'home', component: HomeComponent},
  {path:'login', component: LoginComponent},
  {path:'register', component: RegisterComponent},
  {path:'citizenHome', component: CitizenHomePageComponent},
  {path:'complaintRegister', component: ComplaintRegisterComponent},
  {path:'status', component: CheckStatusComponent},
  {path:'AdminLogin', component:AdminLoginComponent},
  {path:'adminHome', component:AdminHomePageComponent},
  {path:'commisioner', component:CommisionerRegisterComponent},
  {path:'wardOfficer', component:WardOfficerRegisterComponent},
  {path:'siteEngineer', component:SiteEngineerRegisterComponent},
  {path: 'adcomplaintlist', component:AdmincomplaintlistComponent},
  {path:'adminprofile', component:AdminprofileComponent},
  {path:'', redirectTo: '/home', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
