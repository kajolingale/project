import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commisioner-home-page',
  templateUrl: './commisioner-home-page.component.html',
  styleUrls: ['./commisioner-home-page.component.css']
})
export class CommisionerHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
