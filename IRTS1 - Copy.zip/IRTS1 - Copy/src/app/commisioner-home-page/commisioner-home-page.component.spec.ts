import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommisionerHomePageComponent } from './commisioner-home-page.component';

describe('CommisionerHomePageComponent', () => {
  let component: CommisionerHomePageComponent;
  let fixture: ComponentFixture<CommisionerHomePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommisionerHomePageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommisionerHomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
