import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { FormsModule } from '@angular/forms';
import { CitizenHomePageComponent } from './citizen-home-page/citizen-home-page.component';
import { ComplaintRegisterComponent } from './complaint-register/complaint-register.component';
import { CheckStatusComponent } from './check-status/check-status.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomePageComponent } from './admin-home-page/admin-home-page.component';
import { CommisionerRegisterComponent } from './commisioner-register/commisioner-register.component';
import { WardOfficerRegisterComponent } from './ward-officer-register/ward-officer-register.component';
import { SiteEngineerRegisterComponent } from './site-engineer-register/site-engineer-register.component';
import { AdmincomplaintlistComponent } from './admincomplaintlist/admincomplaintlist.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { CommisionerHomePageComponent } from './commisioner-home-page/commisioner-home-page.component'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    CitizenHomePageComponent,
    ComplaintRegisterComponent,
    CheckStatusComponent,
    AdminLoginComponent,
    AdminHomePageComponent,
    CommisionerRegisterComponent,
    WardOfficerRegisterComponent,
    SiteEngineerRegisterComponent,
    AdmincomplaintlistComponent,
    AdminprofileComponent,
    CommisionerHomePageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
