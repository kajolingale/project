import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder} from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  firstName:string
  lastName:string
  email:string
  password:string
  phoneNumber:string
  address:string
  Radio:string

  getData(){
    
    console.log(this.firstName);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
